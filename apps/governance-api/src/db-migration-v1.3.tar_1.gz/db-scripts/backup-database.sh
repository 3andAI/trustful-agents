#!/bin/bash
#
# backup-database.sh
# Creates a full backup of the trustful_agents database before v1.3 migration
#
# Usage:
#   ./backup-database.sh
#
# Creates:
#   - backups/trustful_agents_YYYYMMDD_HHMMSS.sql (full SQL dump)
#   - backups/trustful_agents_YYYYMMDD_HHMMSS.tar (custom format for selective restore)
#

set -e

# Configuration
DB_NAME="${DB_NAME:-trustful_agents}"
DB_USER="${DB_USER:-postgres}"
DB_HOST="${DB_HOST:-localhost}"
BACKUP_DIR="./backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

echo "============================================"
echo "  Trustful Agents Database Backup"
echo "============================================"
echo ""
echo "Database: $DB_NAME"
echo "User: $DB_USER"
echo "Host: $DB_HOST"
echo "Timestamp: $TIMESTAMP"
echo ""

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Check if database exists
if ! psql -U "$DB_USER" -h "$DB_HOST" -lqt | cut -d \| -f 1 | grep -qw "$DB_NAME"; then
    echo "WARNING: Database '$DB_NAME' does not exist. Nothing to backup."
    echo "This is expected for a fresh install."
    exit 0
fi

# Create SQL dump (human-readable, can be edited)
SQL_BACKUP="$BACKUP_DIR/${DB_NAME}_${TIMESTAMP}.sql"
echo "Creating SQL dump: $SQL_BACKUP"
pg_dump -U "$DB_USER" -h "$DB_HOST" -d "$DB_NAME" \
    --no-owner \
    --no-privileges \
    --format=plain \
    > "$SQL_BACKUP"
echo "  [OK] SQL dump created ($(du -h "$SQL_BACKUP" | cut -f1))"

# Create custom format backup (faster restore, selective table restore)
TAR_BACKUP="$BACKUP_DIR/${DB_NAME}_${TIMESTAMP}.tar"
echo "Creating custom format backup: $TAR_BACKUP"
pg_dump -U "$DB_USER" -h "$DB_HOST" -d "$DB_NAME" \
    --no-owner \
    --no-privileges \
    --format=custom \
    > "$TAR_BACKUP"
echo "  [OK] Custom backup created ($(du -h "$TAR_BACKUP" | cut -f1))"

# Create metadata file
META_FILE="$BACKUP_DIR/${DB_NAME}_${TIMESTAMP}.meta"
cat > "$META_FILE" << EOF
Backup Metadata
===============
Database: $DB_NAME
Timestamp: $TIMESTAMP
Created: $(date -u +"%Y-%m-%dT%H:%M:%SZ")
PostgreSQL Version: $(psql -U "$DB_USER" -h "$DB_HOST" -t -c "SELECT version();" | head -1 | xargs)
Pre-Migration Version: v1.2 (before v1.3 evidence changes)

Files:
- SQL Dump: $(basename "$SQL_BACKUP")
- Custom Backup: $(basename "$TAR_BACKUP")

Restore Commands:
- Full restore (SQL): psql -U $DB_USER -h $DB_HOST -d $DB_NAME < $SQL_BACKUP
- Full restore (custom): pg_restore -U $DB_USER -h $DB_HOST -d $DB_NAME $TAR_BACKUP
- Single table: pg_restore -U $DB_USER -h $DB_HOST -d $DB_NAME -t table_name $TAR_BACKUP
EOF
echo "  [OK] Metadata file created"

echo ""
echo "============================================"
echo "  Backup Complete"
echo "============================================"
echo ""
echo "Files created in $BACKUP_DIR:"
ls -lh "$BACKUP_DIR"/${DB_NAME}_${TIMESTAMP}.*
echo ""
echo "To restore from this backup, see: $META_FILE"
