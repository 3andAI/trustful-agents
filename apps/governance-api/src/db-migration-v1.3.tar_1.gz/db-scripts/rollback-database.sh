#!/bin/bash
#
# rollback-database.sh
# Restores the database from a backup
#
# Usage:
#   ./rollback-database.sh <backup_file>
#
# Examples:
#   ./rollback-database.sh backups/trustful_agents_20250127_120000.sql
#   ./rollback-database.sh backups/trustful_agents_20250127_120000.tar
#

set -e

# Configuration
DB_NAME="${DB_NAME:-trustful_agents}"
DB_USER="${DB_USER:-postgres}"
DB_HOST="${DB_HOST:-localhost}"

BACKUP_FILE="$1"

if [ -z "$BACKUP_FILE" ]; then
    echo "Usage: ./rollback-database.sh <backup_file>"
    echo ""
    echo "Available backups:"
    if [ -d "./backups" ]; then
        ls -lh ./backups/*.sql ./backups/*.tar 2>/dev/null || echo "  No backups found"
    else
        echo "  No backups directory found"
    fi
    exit 1
fi

if [ ! -f "$BACKUP_FILE" ]; then
    echo "ERROR: Backup file not found: $BACKUP_FILE"
    exit 1
fi

echo "============================================"
echo "  Trustful Agents Database Rollback"
echo "============================================"
echo ""
echo "Backup file: $BACKUP_FILE"
echo "Target database: $DB_NAME"
echo ""
echo "⚠️  WARNING: This will:"
echo "   1. DROP the existing '$DB_NAME' database"
echo "   2. CREATE a new '$DB_NAME' database"
echo "   3. RESTORE from the backup"
echo ""
read -p "Are you sure? Type 'ROLLBACK' to confirm: " CONFIRM

if [ "$CONFIRM" != "ROLLBACK" ]; then
    echo "Aborted."
    exit 1
fi

echo ""
echo "Step 1: Terminating active connections..."
psql -U "$DB_USER" -h "$DB_HOST" -d postgres -c "
    SELECT pg_terminate_backend(pid) 
    FROM pg_stat_activity 
    WHERE datname = '$DB_NAME' AND pid <> pg_backend_pid();
" 2>/dev/null || true

echo "Step 2: Dropping database..."
psql -U "$DB_USER" -h "$DB_HOST" -d postgres -c "DROP DATABASE IF EXISTS $DB_NAME;"

echo "Step 3: Creating fresh database..."
psql -U "$DB_USER" -h "$DB_HOST" -d postgres -c "CREATE DATABASE $DB_NAME;"

echo "Step 4: Restoring from backup..."
case "$BACKUP_FILE" in
    *.sql)
        echo "  Using SQL restore..."
        psql -U "$DB_USER" -h "$DB_HOST" -d "$DB_NAME" < "$BACKUP_FILE"
        ;;
    *.tar)
        echo "  Using pg_restore..."
        pg_restore -U "$DB_USER" -h "$DB_HOST" -d "$DB_NAME" --no-owner --no-privileges "$BACKUP_FILE"
        ;;
    *)
        echo "ERROR: Unknown backup format. Use .sql or .tar"
        exit 1
        ;;
esac

echo ""
echo "============================================"
echo "  Rollback Complete"
echo "============================================"
echo ""
echo "Database '$DB_NAME' has been restored from:"
echo "  $BACKUP_FILE"
echo ""
echo "Verify with: psql -U $DB_USER -h $DB_HOST -d $DB_NAME -c '\\dt'"
