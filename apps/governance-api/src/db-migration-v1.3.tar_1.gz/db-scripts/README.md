# Trustful Agents v1.3 Database Migration

## Overview

These scripts handle database backup, migration, and rollback for the v1.3 deployment.

### Key Changes in v1.3

The main database change is how evidence is stored:

| Field | v1.2 (Before) | v1.3 (After) |
|-------|---------------|--------------|
| `evidence_uri` | IPFS URL (`ipfs://Qm...`) | **REMOVED** |
| `evidence_data` | N/A | Base64 data URI |
| `evidence_mimetype` | N/A | MIME type (`application/pdf`, etc.) |
| `evidence_size` | N/A | Original file size (max 10KB) |

## Scripts

### 1. backup-database.sh
Creates a backup of the existing database BEFORE migration.

```bash
chmod +x backup-database.sh
./backup-database.sh
```

**Output:**
- `backups/trustful_agents_YYYYMMDD_HHMMSS.sql` - SQL dump
- `backups/trustful_agents_YYYYMMDD_HHMMSS.tar` - Custom format
- `backups/trustful_agents_YYYYMMDD_HHMMSS.meta` - Metadata

### 2. fresh-database-v13.sh
Creates a fresh database with the v1.3 schema.

```bash
chmod +x fresh-database-v13.sh

# If schema.sql is in default location:
./fresh-database-v13.sh

# Or specify the path:
./fresh-database-v13.sh /path/to/governance-api/src/db/schema.sql
```

### 3. rollback-database.sh
Restores the database from a backup if something goes wrong.

```bash
chmod +x rollback-database.sh
./rollback-database.sh backups/trustful_agents_20250127_120000.sql
```

## Recommended Migration Steps

### Step 1: Backup the old database
```bash
cd db-scripts
./backup-database.sh
```

### Step 2: Verify backup was created
```bash
ls -la backups/
```

### Step 3: Create fresh v1.3 database
```bash
./fresh-database-v13.sh /path/to/governance-api/src/db/schema.sql
```

### Step 4: Verify tables were created
```bash
psql -U postgres -d trustful_agents -c "\dt"
```

Expected output:
```
               List of relations
 Schema |       Name        | Type  |  Owner
--------+-------------------+-------+----------
 public | claim_metadata    | table | postgres
 public | claim_messages    | table | postgres
 public | councils          | table | postgres
 public | council_members   | table | postgres
 ... (other tables from schema.sql)
```

### Step 5: If something goes wrong - ROLLBACK
```bash
./rollback-database.sh backups/trustful_agents_YYYYMMDD_HHMMSS.sql
```

## Environment Variables

You can customize the database connection:

```bash
export DB_NAME=trustful_agents
export DB_USER=postgres
export DB_HOST=localhost
```

## Migration File Details

**004_claim_conversations_v13.sql** creates:

1. **claim_metadata** table:
   - `claim_id` (PK)
   - `title` 
   - `description`
   - `created_at`, `updated_at`

2. **claim_messages** table:
   - `id` (UUID)
   - `claim_id`
   - `parent_id` (for threading)
   - `author_address`, `author_role`
   - `content`
   - `evidence_hash` (optional, for integrity)
   - `evidence_data` (base64 data URI)
   - `evidence_filename`
   - `evidence_mimetype`
   - `evidence_size` (max 10KB enforced)
   - `created_at`

## Evidence Storage Format

Evidence is stored as a base64 data URI in the `evidence_data` column:

```
data:application/pdf;base64,JVBERi0xLjQKJeLjz9MK...
```

This allows direct embedding in HTML:
```html
<a href="{{evidence_data}}" download="{{evidence_filename}}">Download</a>
<img src="{{evidence_data}}" /> <!-- for images -->
```

Max file size: **10KB** (becomes ~13.3KB when base64 encoded)
